package com.cleannet.android

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor

/**
 * V1 foundation:
 * Creates a local VPN tunnel.
 *
 * This starter intentionally does not pretend that a simple domain list can
 * reliably remove YouTube/Facebook in-stream ads. Those platforms can serve
 * ads and content from overlapping infrastructure.
 *
 * Next version can add a DNS filtering engine and user-editable blocklists.
 */
class CleanNetVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (vpnInterface == null) {
            vpnInterface = Builder()
                .setSession("CleanNet")
                .addAddress("10.8.0.2", 32)
                .addRoute("10.8.0.0", 24)
                .addDnsServer("1.1.1.1")
                .establish()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        vpnInterface?.close()
        vpnInterface = null
        super.onDestroy()
    }
}
