package com.cleannet.android

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import com.cleannet.android.databinding.ActivityMainBinding

class MainActivity : ComponentActivity() {

    private lateinit var binding: ActivityMainBinding
    private val vpnRequestCode = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.startButton.setOnClickListener {
            val intent = VpnService.prepare(this)
            if (intent != null) {
                startActivityForResult(intent, vpnRequestCode)
            } else {
                startVpn()
            }
        }

        binding.stopButton.setOnClickListener {
            stopService(Intent(this, CleanNetVpnService::class.java))
            binding.statusText.text = "廣告/追蹤阻擋：關閉"
        }
    }

    @Deprecated("Use Activity Result API in a later cleanup pass.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == vpnRequestCode && resultCode == RESULT_OK) {
            startVpn()
        }
    }

    private fun startVpn() {
        startService(Intent(this, CleanNetVpnService::class.java))
        binding.statusText.text = "廣告/追蹤阻擋：已啟用"
    }
}
