# CleanNet-Android

Android 網路過濾器第一版骨架。

## 目標

CleanNet 的方向是：

- 本機 VPN 網路過濾
- 廣告/追蹤網域阻擋
- 自訂封鎖清單
- 統計被阻擋的請求
- 允許使用者暫停/恢復

## 重要限制

YouTube、Facebook 等大型影音平台可能讓廣告與影片內容共用網域/CDN，因此「單純封鎖廣告網域」無法保證移除 App 內所有影片廣告，而且過度封鎖可能造成影片無法播放。

V1 先建立合法、通用的本機網路過濾架構；後續可加入 DNS 過濾、追蹤器阻擋與統計功能。

## 開啟方式

用 Android Studio 開啟本專案，等待 Gradle Sync 後 Build APK。
